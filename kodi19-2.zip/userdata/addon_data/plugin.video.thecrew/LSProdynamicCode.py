#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m,url = 'http://thechains24.com/GREENHAT/main.tv.shows.GREEN.xml'):
    from resources.lib.modules import control
    if not control.infoLabel('Container.PluginName') == 'plugin.video.thecrew': return
    from resources.lib.indexers import lists
    lists.indexer().get(url)